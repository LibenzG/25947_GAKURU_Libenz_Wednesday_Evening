interface Payroll {
    double calculatePermanent(double salary);
    double calculateCasual(double salary);
    double calculateContractual(double salary);
}