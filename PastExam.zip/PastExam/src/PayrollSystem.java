import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PayrollSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continueRunning = true;

        while (continueRunning) {
            List<Employee> employees = new ArrayList<>();

            System.out.println("----------------------------------");
            System.out.println("WELCOME TO OUR PAYROLL SYSTEM");
            System.out.println("----------------------------------");

            // Ask for the number of employees
            int numberOfEmployees = getValidatedIntInput(scanner, "How many employees would you like to enter? ", 1, Integer.MAX_VALUE);

            System.out.println("Enter Employee Details for " + numberOfEmployees + " people\n");

            for (int i = 1; i <= numberOfEmployees; i++) {
                System.out.println("Employee " + i);
                int employeeId = getValidatedIntInput(scanner, "Enter Employee ID (numeric): ", 1, Integer.MAX_VALUE);
                String firstName = getValidatedStringInput(scanner, "Enter First Name: ");
                String lastName = getValidatedStringInput(scanner, "Enter Last Name: ");
                String dateOfBirth = getValidatedStringInput(scanner, "Enter Date of Birth (yyyy-MM-dd): ");
                int age = getValidatedIntInput(scanner, "Enter Age (20-65): ", 20, 65);
                String department = getValidatedStringInput(scanner, "Enter Department (Accounting, Planning, Strategy, Human Resources): ",
                        "Accounting", "Planning", "Strategy", "Human Resources");
                int yearsOfExperience = getValidatedIntInput(scanner, "Enter Years of Experience (minimum 5): ", 5, Integer.MAX_VALUE);
                double salary = getValidatedDoubleInput(scanner, "Enter Salary: ", 0, Double.MAX_VALUE);
                int employeeType = getValidatedIntInput(scanner, "Enter Employee Type (1 for Permanent, 2 for Casual, 3 for Contractual): ", 1, 3);

                // Create Employee
                Employee employee = createEmployee(employeeType, employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
                if (employee != null) {
                    employees.add(employee);
                }

                System.out.println();
            }

            // Display Summary
            System.out.println("Employee Data Summary:");
            for (Employee emp : employees) {
                System.out.println("_______________________________________________________________");
                System.out.println("ID: " + emp.employeeId);
                System.out.println("Name: " + emp.firstName + " " + emp.lastName);
                System.out.println("Date of Birth: " + emp.dateOfBirth);
                System.out.println("Department: " + emp.department);
                System.out.println("Salary: " + emp.salary);
                System.out.println("Deductions:");
                System.out.println(" - Pension: " + emp.calculatePension());
                System.out.println(" - CBHI: " + emp.calculateCBHI());
                System.out.println(" - Maternity: " + emp.calculateMaternity());
                System.out.println("Final Salary after deductions: " + emp.calculateFinalSalary());
            }

            // Prompt to Recalculate or Exit
            System.out.println("\nDo you want to recalculate or exit? ");
            System.out.println("1. Recalculate");
            System.out.println("2. Exit");
            int choice = getValidatedIntInput(scanner, "Enter your choice: ", 1, 2);

            if (choice == 2) {
                continueRunning = false;
                System.out.println("Thank you for using the Payroll System. Goodbye!");
            }
        }

        scanner.close();
    }

    // Helper methods for validation
    private static int getValidatedIntInput(Scanner scanner, String prompt, int min, int max) {
        int value;
        while (true) {
            try {
                System.out.print(prompt);
                value = Integer.parseInt(scanner.nextLine());
                if (value < min || value > max) throw new IllegalArgumentException("Value must be between " + min + " and " + max + ".");
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
    }

    private static double getValidatedDoubleInput(Scanner scanner, String prompt, double min, double max) {
        double value;
        while (true) {
            try {
                System.out.print(prompt);
                value = Double.parseDouble(scanner.nextLine());
                if (value < min || value > max) throw new IllegalArgumentException("Value must be between " + min + " and " + max + ".");
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
    }

    private static String getValidatedStringInput(Scanner scanner, String prompt, String... validOptions) {
        String value;
        while (true) {
            try {
                System.out.print(prompt);
                value = scanner.nextLine().trim();
                if (validOptions.length > 0) {
                    boolean isValid = false;
                    for (String option : validOptions) {
                        if (value.equalsIgnoreCase(option)) {
                            isValid = true;
                            break;
                        }
                    }
                    if (!isValid) throw new IllegalArgumentException("Valid options are: " + String.join(", ", validOptions) + ".");
                } else if (value.isEmpty()) {
                    throw new IllegalArgumentException("Input cannot be empty.");
                }
                return value;
            } catch (Exception e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
    }

    private static Employee createEmployee(int employeeType, int employeeId, String firstName, String lastName, String dateOfBirth, int age, String department, int yearsOfExperience, double salary) {
        try {
            return switch (employeeType) {
                case 1 -> {
                    if (salary < 1000000 || salary > 1500000)
                        throw new IllegalArgumentException("Salary must be within 1,000,000 to 1,500,000 for Permanent Employees.");
                    yield new PermanentEmployee(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
                }
                case 2 -> {
                    if (salary < 700000 || salary > 850000)
                        throw new IllegalArgumentException("Salary must be within 700,000 to 850,000 for Casual Employees.");
                    yield new CasualEmployee(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
                }
                case 3 -> {
                    if (salary >= 500000)
                        throw new IllegalArgumentException("Salary must be below 500,000 for Contractual Employees.");
                    yield new ContractualEmployee(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
                }
                default -> null;
            };
        } catch (Exception e) {
            System.out.println("Error creating employee: " + e.getMessage());
            return null;
        }
    }
}



