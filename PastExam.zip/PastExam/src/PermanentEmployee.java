class PermanentEmployee extends Employee {
    public PermanentEmployee(int employeeId, String firstName, String lastName, String dateOfBirth, int age, String department, int yearsOfExperience, double salary) {
        super(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
    }

    @Override
    public double calculatePension() {
        return salary * 0.02;
    }

    @Override
    public double calculateCBHI() {
        return salary * 0.05;
    }

    @Override
    public double calculateMaternity() {
        return salary * 0.026;
    }
}