public class CasualEmployee extends Employee {

    // Constructor for CasualEmployee
    public CasualEmployee(int employeeId, String firstName, String lastName, String dateOfBirth, int age, String department, int yearsOfExperience, double salary) {
        super(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
    }

    // Override the calculatePension method specific to CasualEmployee
    @Override
    public double calculatePension() {
        // Casual Employees may have a lower pension rate compared to permanent employees
        return this.salary * 0.03;  // Example: 3% of salary for pension
    }

    // Override the calculateCBHI method specific to CasualEmployee
    @Override
    public double calculateCBHI() {
        // Example: Casual employees may have a different CBHI contribution rate
        return this.salary * 0.01;  // Example: 1% of salary for CBHI
    }

    // Override the calculateMaternity method specific to CasualEmployee
    @Override
    public double calculateMaternity() {
        // Casual Employees might have different maternity deductions, or none at all
        return 0;  // Example: No maternity deduction for Casual Employees
    }

    // Override the calculateFinalSalary method for CasualEmployee
    @Override
    public double calculateFinalSalary() {
        double totalDeductions = calculatePension() + calculateCBHI() + calculateMaternity();
        return this.salary - totalDeductions;
    }
}
