abstract class Employee {
    int employeeId;
    String firstName;
    String lastName;
    String dateOfBirth;
    int age;
    String department;
    int yearsOfExperience;
    double salary;

    public Employee(int employeeId, String firstName, String lastName, String dateOfBirth, int age, String department, int yearsOfExperience, double salary) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.age = age;
        this.department = department;
        this.yearsOfExperience = yearsOfExperience;
        this.salary = salary;
    }

    public abstract double calculatePension();

    public abstract double calculateCBHI();

    public abstract double calculateMaternity();

    public double calculateFinalSalary() {
        return salary - (calculatePension() + calculateCBHI() + calculateMaternity());
    }
}